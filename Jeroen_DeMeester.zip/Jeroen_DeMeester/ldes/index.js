const express = require('express');
const path = require('path');
const fsPromises = require('fs/promises');
const fs = require('fs');
const { DataFactory, StreamParser, Store, Writer } = require('n3');
const { quad, namedNode, blankNode, literal } = DataFactory;

const app = express();
const port = 3000;

const BASE_URL = "http://localhost:3000/ldes";

const RDF = "http://www.w3.org/1999/02/22-rdf-syntax-ns#";
const XSD = "http://www.w3.org/2001/XMLSchema#";
const TREE = "https://w3id.org/tree#";
const DCT = "http://purl.org/dc/terms/";
const LDES = "https://w3id.org/ldes#";
const PERSON = "http://www.w3.org/ns/person#";

// State map that contains the set of available fragments
const fragments = new Map();

// Redirect to the first fragment (a.k.a tree:view)
app.get('/ldes', (req, res) => {
    const sortedFragments = Array.from(fragments.values()).sort((a, b) => a.lastModified - b.lastModified);

    // Handle trailing slash
    const redirectPath = req.url.endsWith('/')
        ? req.url + sortedFragments[0].name
        : req.url + '/' + sortedFragments[0].name

    res.redirect(redirectPath);
});

// Route handler for a specific fragment
app.get('/ldes/:fragment', async (req, res) => {

    if (fragments.has(req.params.fragment)) {

        const fragmentName = fragments.get(req.params.fragment).name;
        const store = new Store();
        const rdfStream = fs.createReadStream(path.join(__dirname, 'data', fragmentName)).pipe(new StreamParser());

        for await (const q of rdfStream) {
            store.addQuad(q);
        }

        const sortedFragments = Array.from(fragments.values()).sort((a, b) => a.lastModified - b.lastModified);
        const index = sortedFragments.findIndex(f => f.name === fragmentName);

        const firstFragmentUrl = `${BASE_URL}/${sortedFragments[0].name}`;
        const currentFragmentUrl = `${BASE_URL}/${fragmentName}`;

        // Zoek alle person:Person members in dit fragment
        const members = store.getQuads(
            null,
            namedNode(`${RDF}type`),
            namedNode(`${PERSON}Person`),
            null
        ).map(q => q.subject);

        // Event stream metadata
        store.addQuad(quad(
            namedNode(BASE_URL),
            namedNode(`${RDF}type`),
            namedNode(`${LDES}EventStream`)
        ));

        store.addQuad(quad(
            namedNode(BASE_URL),
            namedNode(`${LDES}timestampPath`),
            namedNode(`${DCT}modified`)
        ));

        store.addQuad(quad(
            namedNode(BASE_URL),
            namedNode(`${LDES}versionOfPath`),
            namedNode(`${DCT}isVersionOf`)
        ));

        // tree:view naar het eerste fragment
        store.addQuad(quad(
            namedNode(BASE_URL),
            namedNode(`${TREE}view`),
            namedNode(firstFragmentUrl)
        ));

        // tree:member triples
        for (const member of members) {
            store.addQuad(quad(
                namedNode(BASE_URL),
                namedNode(`${TREE}member`),
                member
            ));
        }

        // current fragment is een tree:Node
        store.addQuad(quad(
            namedNode(currentFragmentUrl),
            namedNode(`${RDF}type`),
            namedNode(`${TREE}Node`)
        ));

        // tree:relation naar volgend fragment, als dat bestaat
        if (index < sortedFragments.length - 1) {
            const nextFragment = sortedFragments[index + 1];
            const relationNode = blankNode();
            const greaterThanValue = findGreaterThanValue(store);

            store.addQuad(quad(
                namedNode(currentFragmentUrl),
                namedNode(`${TREE}relation`),
                relationNode
            ));

            store.addQuad(quad(
                relationNode,
                namedNode(`${RDF}type`),
                namedNode(`${TREE}GreaterThanRelation`)
            ));

            store.addQuad(quad(
                relationNode,
                namedNode(`${TREE}node`),
                namedNode(`${BASE_URL}/${nextFragment.name}`)
            ));

            store.addQuad(quad(
                relationNode,
                namedNode(`${TREE}path`),
                namedNode(`${DCT}modified`)
            ));

            store.addQuad(quad(
                relationNode,
                namedNode(`${TREE}value`),
                literal(greaterThanValue, namedNode(`${XSD}dateTime`))
            ));
        }

        // Cache-Control header
        if (index === sortedFragments.length - 1) {
            res.set('Cache-Control', 'max-age=10');
        } else {
            res.set('Cache-Control', 'immutable');
        }

        // Serialize store naar Turtle en stuur response
        const writer = new Writer({
            prefixes: {
                rdf: RDF,
                xsd: XSD,
                tree: TREE,
                dct: DCT,
                ldes: LDES,
                person: PERSON
            }
        });

        writer.addQuads(store.getQuads(null, null, null, null));

        writer.end((err, result) => {
            if (err) {
                res.status(500).send(err.message);
                return;
            }

            res.set('Content-Type', 'text/turtle');
            res.send(result);
        });

    } else {
        res.status(404).send('Not found');
        return;
    }
});

// Start HTTP server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}/`);
});

// Function to monitor the data folder and refresh the state array
fs.watch(path.join(__dirname, 'data'), updateState);

// Function to update the state array
async function updateState() {
    console.log("Storage state change detected!");
    const files = await fsPromises.readdir(path.join(__dirname, 'data'));

    for (const fileName of files) {
        // Read the last modified time of this file
        const lastModified = (await fsPromises.stat(path.join(__dirname, 'data', fileName))).mtimeMs;
        // Add it to the state map
        fragments.set(fileName, { name: fileName, lastModified });
    }
}

// Function to extract the member timestamps from a RDF-JS Store and return the most recent one
function findGreaterThanValue(store) {
    const values = store.getQuads(null, namedNode(`${DCT}modified`), null, null).map(q => {
        return new Date(q.object.value).getTime();
    });

    values.sort((a, b) => b - a);
    return new Date(values[0]).toISOString();
}

// Initialize the state array at start up
updateState();
